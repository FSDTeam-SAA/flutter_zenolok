import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/network/models/network_failure.dart';
import '../../../../core/network/models/network_success.dart';

import '../../data/models/brick_model.dart';
import '../../data/models/category_design.dart';
import '../../data/models/create_brick_request_model.dart';
import '../../domain/repo/brick_repo.dart';

class BrickController extends GetxController {
  BrickController({required BrickRepository repository})
    : _repository = repository;

  final BrickRepository _repository;

  final RxBool isLoading = false.obs;
  final RxnString errorMessage = RxnString();

  late final RxList<BrickModel> bricks = <BrickModel>[].obs;

  void resetDesign() {
    design.value = const CategoryDesign(
      color: null,
      icon: Icons.work_outline,
      iconKey: 'ri-focus-2-fill',
      name: '',
    );
    errorMessage.value = null;
  }






  /// ✅ Editor state (start grey)
  final Rx<CategoryDesign> design = const CategoryDesign(
    color: null,
    icon: Icons.work_outline,
    iconKey: 'ri-focus-2-fill',
    name: '',
  ).obs;

  bool get hasColor => design.value.color != null;

  void updateDesign(CategoryDesign d) {
    design.value = d;
  }

  /// Flutter Color -> "#RRGGBB"
  String _colorToHex(Color color) {
    final value = color.value.toRadixString(16).padLeft(8, '0'); // AARRGGBB
    return '#${value.substring(2).toUpperCase()}'; // RRGGBB
  }

  Future<BrickModel?> createBrick() async {
    final d = design.value;

    if (d.color == null) {
      errorMessage.value = 'Select a color before adding a brick.';
      return null;
    }

    isLoading.value = true;
    errorMessage.value = null;
    update(); // ✅ so GetBuilder UIs can show loading if you want

    final request = CreateBrickRequestModel(
      name: d.name.trim().isEmpty ? 'Bricks' : d.name.trim(),
      color: _colorToHex(d.color!),
      icon: d.iconKey,
    );

    final Either<NetworkFailure, NetworkSuccess<BrickModel>> result =
    await _repository.createBrick(request);

    BrickModel? created;

    result.fold(
          (failure) => errorMessage.value = failure.message,
          (success) {
        created = success.data;

        // ✅ Update list
        bricks.add(success.data);

        // ✅ IMPORTANT: rebuild GetBuilder widgets immediately
        update();

        // Optional: also refresh Rx listeners
        bricks.refresh();

        resetDesign();
      },
    );

    isLoading.value = false;
    update(); // ✅ reflect loading false in GetBuilder screens

    return created;
  }

  Future<void> loadBricks() async {
    isLoading.value = true;
    errorMessage.value = null;
    update(); // ✅ rebuild before fetch (optional)

    final Either<NetworkFailure, NetworkSuccess<List<BrickModel>>> result =
    await _repository.getBricks();

    result.fold(
          (failure) => errorMessage.value = failure.message,
          (success) {
        // ✅ Update list FIRST
        bricks.assignAll(success.data);
        bricks.refresh();
      },
    );

    isLoading.value = false;

    // ✅ IMPORTANT: rebuild AFTER the list is updated
    update();
  }
}
